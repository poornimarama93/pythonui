from flask import Flask, render_template, request
import requests  

app = Flask(__name__)

@app.route('/')
def home():

    return render_template('index.html')

@app.route('/result',methods = ['POST', 'GET'])
def result():
   if request.method == 'POST':
      result = request.form
      return render_template("result.html",result = result)

@app.route('/score', methods=['POST'])
def score():
    if request.method == 'POST':
        target_industry = request.form['target_industry']
        target_name = request.form['target_name']
        target_title = request.form['target_title']
        subject = request.form['subject']
        content = request.form['content']

        # Handle potential empty content input
        if not content:
            return jsonify({'error': 'Please enter some content in the text box.'}), 400

        # Assuming the external API returns JSON (modify if necessary)
        response_score = requests.post(
            'https://zafocontentscoring.onrender.com/scorer',
            json={'subject': subject, 'content': content, 'date': '2024-10-10 06:20:27 UTC'}
        )
        print('first call made')

        response_suggestion = requests.post(
            'https://zafocontentscoring.onrender.com/suggestions',
            json={'target_title': target_title, 'target_name': target_name, 'target_industry': target_industry,'core_message': content}
        )
        print('second call made')

        if ((response_score.status_code == 200) and (response_suggestion.status_code == 200)):
            print('inside')
            
            data_score = response_score.json()
            data_suggestion = response_suggestion.json()
            score = data_score.get('score', 0.0)  # Handle missing score gracefully
            suggestions = data_suggestion.get('suggestions', 'Default suggestion')
            return render_template('result.html', score=score, suggestions=suggestions)
        else:
            error_message = f"Error: API call failed with status code {response_score.status_code} and {response_suggestion.status_code}"
            return render_template('result.html', score=None, error=error_message), 500

    return render_template('index.html')  # Handle GET requests gracefully

if __name__ == '__main__':
    app.run()